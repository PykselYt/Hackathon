@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python detector_intersectie.py --configurare
pause
