#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Detector de vehicule in intersectie - LIVE, direct de pe ecran.

 - captureaza ecranul (sau o zona din el) unde ruleaza camera
 - detecteaza masini, autobuze si tramvaie si le urmareste de la un cadru la altul
 - deseneaza CONTURUL fiecarui vehicul (segmentare), nu un dreptunghi
 - pentru fiecare vehicul: in miscare / oprit (de cat timp) + directia de deplasare
 - invata singur unde e drumul (pe unde circula vehiculele); masinile oprite in afara
   drumului sau nemiscate foarte mult timp sunt considerate parcate si ignorate

Utilizare:
  python detector_intersectie.py                  # live, contururi peste ecran
  python detector_intersectie.py --configurare    # alegi zona de ecran (+ zone optionale)
  python detector_intersectie.py --mod fereastra  # imaginea adnotata intr-o fereastra separata
  python detector_intersectie.py --video clip.mp4 --salveaza rezultat.mp4
"""
import argparse
import json
import math
import os
import sys
import threading
import time
from collections import Counter, deque

import numpy as np
import cv2

AICI = os.path.dirname(os.path.abspath(__file__))
CONFIG_IMPLICIT = os.path.join(AICI, "config_intersectie.json")
HARTA_IMPLICIT = os.path.join(AICI, "harta_trafic.npz")
MODEL_IMPLICIT = "yoloe-26s-seg.pt"
MODEL_REZERVA = "yolo11s-seg.pt"

# ---------------------------------------------------------------------------
# Setari (pot fi ajustate)
# ---------------------------------------------------------------------------
SETARI = dict(
    conf_min=0.15,            # detectiile mai slabe de atat sunt ignorate
    conf_nou=0.35,            # incredere minima ca sa porneasca o pista noua
    fereastra_viteza=2.0,     # secunde de istoric folosite pentru viteza/directie
    # miscare: pixeli/secunda; pragul creste putin cu marimea vehiculului
    miscare_px=2.5, miscare_rel=0.05,
    oprire_px=1.2, oprire_rel=0.025,
    parcat_dupa=120,          # s: nemiscat atat timp -> parcat, chiar si pe drum (nu tramvai/autobuz)
    parcat_afara_nemiscat=4,  # s: in afara drumului, nu s-a miscat deloc -> parcat
    parcat_afara_oprit=15,    # s: in afara drumului, a mers si apoi a stat -> parcat
    parcat_zona_parcare=2,    # s: oprit intr-o zona "parcare" desenata -> parcat
    parcat_harta_neinvatata=45,  # s: cat timp harta drumului inca nu e invatata
    pastrare_miscare=1.0,     # s: cat tinem minte o pista in miscare care a disparut
    pastrare_oprit=8.0,       # s: ... una oprita (ex. acoperita de un tramvai)
    pastrare_parcat=30.0,     # s: ... una parcata
)

# cuvintele cautate de modelul YOLOE (si categoria in care intra)
PROMPTURI = ["car", "van", "truck", "bus", "tram", "motorcycle"]
NUME_LA_CAT = {"car": "masina", "van": "masina", "truck": "masina", "motorcycle": "masina",
               "bus": "autobuz", "tram": "tramvai", "train": "tramvai"}
NUME_CAT = {"masina": "MASINA", "autobuz": "AUTOBUZ", "tramvai": "TRAMVAI"}

CULORI = {
    ("masina", "miscare"): "#22e03a",
    ("masina", "oprit"): "#ff2d2d",
    ("autobuz", "miscare"): "#1e90ff",
    ("autobuz", "oprit"): "#1e90ff",
    ("tramvai", "miscare"): "#d63cff",
    ("tramvai", "oprit"): "#d63cff",
    "parcat": "#9a9a9a",
    "nou": "#e0e0e0",
    "oprit_tag": "#ff2d2d",
}
CULORI_ZONE = {"drum": "#ffd400", "tramvai": "#d63cff", "parcare": "#9a9a9a"}
CULOARE_HARTA = "#00e5ff"

DIRECTII = ["dreapta", "sus-dreapta", "sus", "sus-stanga", "stanga", "jos-stanga", "jos", "jos-dreapta"]
SAGETI = ["→", "↗", "↑", "↖", "←", "↙", "↓", "↘"]


def hex_bgr(h):
    h = h.lstrip("#")
    return (int(h[4:6], 16), int(h[2:4], 16), int(h[0:2], 16))


def simplifica_contur(p):
    """Contur de la segmentare -> poligon convex, cu putine puncte."""
    if p is None or len(p) < 3:
        return None
    p = np.asarray(p, np.float32).reshape(-1, 1, 2)
    h = cv2.convexHull(p)
    a = cv2.approxPolyDP(h, max(1.0, 0.012 * cv2.arcLength(h, True)), True).reshape(-1, 2)
    return a if len(a) >= 3 else None


# ---------------------------------------------------------------------------
# Zone optionale desenate de utilizator (coordonate relative 0..1)
# ---------------------------------------------------------------------------
class Zone:
    def __init__(self, zone_rel=None):
        self.rel = {k: [list(map(list, p)) for p in v] for k, v in (zone_rel or {}).items()}
        self.marime = None
        self.px = {}

    def pregateste(self, w, h):
        if self.marime == (w, h):
            return
        self.marime = (w, h)
        self.px = {
            k: [np.array([[x * w, y * h] for x, y in p], np.float32) for p in v if len(p) >= 3]
            for k, v in self.rel.items()
        }

    def are(self, tip):
        return bool(self.px.get(tip))

    def contine(self, tip, pt):
        for p in self.px.get(tip, []):
            if cv2.pointPolygonTest(p, (float(pt[0]), float(pt[1])), False) >= 0:
                return True
        return False


# ---------------------------------------------------------------------------
# Harta drumului, invatata din traseele vehiculelor in miscare
# ---------------------------------------------------------------------------
class HartaTrafic:
    GW, GH = 192, 108

    def __init__(self, cale=None, meta=None):
        self.cale = cale
        self.M = np.zeros((self.GH, self.GW), np.float32)
        self.total = 0.0
        self.meta = meta or {}
        self._prag_calc = 0.0
        self._prag = float("inf")
        self._Mb = self.M
        self._contur = None
        self._contur_t = 0.0
        self._ultima_salvare = time.time()
        if cale and os.path.exists(cale):
            try:
                d = np.load(cale, allow_pickle=False)
                meta_f = json.loads(str(d["meta"]))
                if meta is None or meta_f == meta:
                    self.M = d["M"].astype(np.float32)
                    self.total = float(d["total"])
                    print(f"Harta drumului incarcata ({self.total / 60:.0f} min de trafic invatat).")
                else:
                    print("Zona de ecran s-a schimbat: invat harta drumului de la zero.")
            except Exception as ex:
                print("Nu pot citi harta drumului:", ex)

    def _celule(self, box, W, H, fx=0.2, fy=0.3):
        x1, y1, x2, y2 = box
        w, h = x2 - x1, y2 - y1
        gx1 = int((x1 + fx * w) / W * self.GW)
        gx2 = int(math.ceil((x2 - fx * w) / W * self.GW))
        gy1 = int((y2 - fy * h) / H * self.GH)
        gy2 = int(math.ceil(y2 / H * self.GH))
        gx1, gy1 = max(0, gx1), max(0, gy1)
        gx2, gy2 = min(self.GW, max(gx2, gx1 + 1)), min(self.GH, max(gy2, gy1 + 1))
        return gx1, gy1, gx2, gy2

    def adauga(self, box, dt, W, H):
        gx1, gy1, gx2, gy2 = self._celule(box, W, H)
        self.M[gy1:gy2, gx1:gx2] += dt
        self.total += dt

    def _actualizeaza_prag(self):
        if time.time() - self._prag_calc < 2.0:
            return
        self._prag_calc = time.time()
        v = self.M[self.M > 0]
        if len(v) < 30:
            self._prag = float("inf")
            return
        self._prag = max(1.5, 0.08 * float(np.percentile(v, 90)))
        self._Mb = cv2.GaussianBlur(self.M, (3, 3), 0)

    def invatata(self):
        return self.total >= 180

    def e_drum(self, box, W, H):
        self._actualizeaza_prag()
        x1, y1, x2, y2 = box
        gx = min(self.GW - 1, max(0, int((x1 + x2) / 2 / W * self.GW)))
        gy = min(self.GH - 1, max(0, int((y2 - 0.12 * (y2 - y1)) / H * self.GH)))
        return self._Mb[gy, gx] >= self._prag

    def contururi(self, W, H):
        """Conturul zonelor de drum invatate, in pixeli (pentru afisare)."""
        if self._contur is not None and time.time() - self._contur_t < 3:
            return self._contur
        self._actualizeaza_prag()
        masca = (self._Mb >= self._prag).astype(np.uint8) * 255
        masca = cv2.morphologyEx(masca, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        cts, _ = cv2.findContours(masca, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        sx, sy = W / self.GW, H / self.GH
        self._contur = [(c.reshape(-1, 2) * [sx, sy]).astype(np.int32) for c in cts if cv2.contourArea(c) >= 4]
        self._contur_t = time.time()
        return self._contur

    def roi(self, W, H, zone=None):
        """Dreptunghiul care cuprinde drumul invatat (+ margine), sau None."""
        if not self.invatata():
            return None
        if getattr(self, "_roi_t", 0) and time.time() - self._roi_t < 30:
            return self._roi
        self._actualizeaza_prag()
        ys, xs = np.nonzero(self._Mb >= self._prag)
        if len(xs) < 10:
            return None
        x1, x2 = xs.min() / self.GW * W, (xs.max() + 1) / self.GW * W
        y1, y2 = ys.min() / self.GH * H, (ys.max() + 1) / self.GH * H
        if zone is not None:
            zone.pregateste(W, H)
            for polis in zone.px.values():
                for p in polis:
                    x1, y1 = min(x1, p[:, 0].min()), min(y1, p[:, 1].min())
                    x2, y2 = max(x2, p[:, 0].max()), max(y2, p[:, 1].max())
        # margine: lateral 6%, sus 14% (vehiculele se intind deasupra punctului de pe sol), jos 4%
        r = (int(max(0, x1 - 0.06 * W)), int(max(0, y1 - 0.14 * H)),
             int(min(W, x2 + 0.06 * W)), int(min(H, y2 + 0.04 * H)))
        if (r[2] - r[0]) * (r[3] - r[1]) > 0.85 * W * H:
            r = None
        vechi = getattr(self, "_roi", None)
        if vechi is None or r is None or max(abs(a - b) for a, b in zip(r, vechi)) > 0.04 * max(W, H):
            self._roi = r      # schimbam doar daca difera clar (forma stabila = mai rapid)
        self._roi_t = time.time()
        return self._roi

    def salveaza(self, fortat=False):
        if not self.cale or (not fortat and time.time() - self._ultima_salvare < 60):
            return
        self._ultima_salvare = time.time()
        try:
            np.savez_compressed(self.cale, M=self.M, total=np.float64(self.total),
                                meta=json.dumps(self.meta, sort_keys=True))
        except Exception as ex:
            print("Nu pot salva harta drumului:", ex)


# ---------------------------------------------------------------------------
# Urmarire (tracking)
# ---------------------------------------------------------------------------
def iou_matrice(a, b):
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, None, 0], b[None, :, 0])
    y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2])
    y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    aa = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    ab = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (aa[:, None] + ab[None, :] - inter + 1e-9)


class Pista:
    _urmatorul = 1

    def __init__(self, box, conf, cat, poly, t):
        self.id = Pista._urmatorul
        Pista._urmatorul += 1
        self.box = np.array(box, float)
        self.poligon = poly
        self.vel = np.zeros(2)
        self.t_start = self.t_ultim = t
        self.hits = 1
        self.voturi = Counter()
        self.voturi[cat] += conf
        self.istoric = deque()
        self._adauga_istoric(t)
        self.poz_start = self.centru()
        self.stare = "nou"          # nou / miscare / oprit
        self.a_miscat = False       # a parcurs cel putin o lungime de vehicul
        self.parcurs = 0.0
        self.t_oprit = t
        self.parcat = False
        self.poz_parcare = None
        self.directie = None        # vector unitate (dx, dy) in coordonate ecran

    def centru(self):
        b = self.box
        return np.array([(b[0] + b[2]) / 2, (b[1] + b[3]) / 2])

    def inaltime(self):
        return max(4.0, self.box[3] - self.box[1])

    def categorie(self):
        return self.voturi.most_common(1)[0][0]

    def _adauga_istoric(self, t):
        self.istoric.append((t, *self.box))
        while self.istoric and t - self.istoric[0][0] > 5.0:
            self.istoric.popleft()

    def box_prezis(self, t):
        if self.stare != "miscare":
            return self.box
        dt = min(t - self.t_ultim, 1.0)
        dx, dy = self.vel * dt
        return self.box + np.array([dx, dy, dx, dy])

    def actualizeaza(self, box, conf, cat, poly, t):
        dt = t - self.t_ultim
        c_vechi = self.centru()
        self.box = 0.3 * self.box_prezis(t) + 0.7 * np.asarray(box, float)
        self.poligon = poly
        if dt > 1e-3:
            inst = (self.centru() - c_vechi) / dt
            self.vel = 0.6 * self.vel + 0.4 * inst
        self.t_ultim = t
        self.hits += 1
        self.voturi[cat] += conf
        self._adauga_istoric(t)

    def pastrare(self):
        if self.parcat:
            return SETARI["pastrare_parcat"]
        if self.stare == "miscare":
            return SETARI["pastrare_miscare"]
        return SETARI["pastrare_oprit"]


class Urmaritor:
    def __init__(self):
        self.piste = []

    @staticmethod
    def _similaritate(A, B):
        iou = iou_matrice(A, B)
        ca = np.stack([(A[:, 0] + A[:, 2]) / 2, (A[:, 1] + A[:, 3]) / 2], 1)
        cb = np.stack([(B[:, 0] + B[:, 2]) / 2, (B[:, 1] + B[:, 3]) / 2], 1)
        d = np.linalg.norm(ca[:, None] - cb[None], axis=2)
        sz = np.maximum(A[:, 2] - A[:, 0], A[:, 3] - A[:, 1])[:, None]
        scor_dist = np.clip(1 - d / (0.8 * sz + 1e-9), 0, 1)
        ha = (A[:, 3] - A[:, 1])[:, None]
        hb = (B[:, 3] - B[:, 1])[None, :]
        raport = np.minimum(ha, hb) / (np.maximum(ha, hb) + 1e-9)
        return np.maximum(iou, 0.6 * scor_dist) * (raport > 0.45)

    def _asociaza(self, idx_piste, idx_det, boxes, t, prag, doar_iou=False):
        if not idx_piste or len(idx_det) == 0:
            return [], idx_piste, list(idx_det)
        from scipy.optimize import linear_sum_assignment
        A = np.array([self.piste[i].box_prezis(t) for i in idx_piste])
        B = boxes[idx_det]
        S = iou_matrice(A, B) if doar_iou else self._similaritate(A, B)
        r, c = linear_sum_assignment(-S)
        perechi, fol_p, fol_d = [], set(), set()
        for i, j in zip(r, c):
            if S[i, j] >= prag:
                perechi.append((idx_piste[i], idx_det[j]))
                fol_p.add(i)
                fol_d.add(j)
        rest_p = [p for k, p in enumerate(idx_piste) if k not in fol_p]
        rest_d = [d for k, d in enumerate(idx_det) if k not in fol_d]
        return perechi, rest_p, rest_d

    def actualizeaza(self, boxes, confs, cats, polys, t):
        idx_mare = [i for i in range(len(boxes)) if confs[i] >= SETARI["conf_nou"]]
        idx_mic = [i for i in range(len(boxes)) if confs[i] < SETARI["conf_nou"]]
        toate = list(range(len(self.piste)))
        p1, rest_p, rest_d = self._asociaza(toate, idx_mare, boxes, t, 0.2)
        p2, rest_p, _ = self._asociaza(rest_p, idx_mic, boxes, t, 0.3, doar_iou=True)
        for ip, idd in p1 + p2:
            self.piste[ip].actualizeaza(boxes[idd], confs[idd], cats[idd], polys[idd], t)
        existente = np.array([p.box for p in self.piste]) if self.piste else np.zeros((0, 4))
        for idd in rest_d:
            if len(existente) and iou_matrice(boxes[idd:idd + 1], existente).max() > 0.6:
                continue  # dublura peste o pista existenta
            self.piste.append(Pista(boxes[idd], confs[idd], cats[idd], polys[idd], t))
        self.piste = [p for p in self.piste if t - p.t_ultim <= p.pastrare()]


# ---------------------------------------------------------------------------
# Analiza: miscare / oprit / parcat / directie
# ---------------------------------------------------------------------------
class Analizor:
    def __init__(self, zone, harta=None):
        self.zone = zone
        self.harta = harta or HartaTrafic()
        self.urm = Urmaritor()
        self.t = 0.0
        self.marime = (1, 1)

    def actualizeaza(self, boxes, confs, cats, polys, t, marime):
        dt = t - self.t if self.t else 0.0
        self.t = t
        self.marime = marime
        self.zone.pregateste(*marime)
        boxes = np.asarray(boxes, float).reshape(-1, 4)
        cats = list(cats)
        if polys is None:
            polys = [None] * len(boxes)
        for i, b in enumerate(boxes):
            if cats[i] == "autobuz" and self.zone.contine("tramvai", ((b[0] + b[2]) / 2, b[3])):
                cats[i] = "tramvai"  # doar daca utilizatorul a desenat zona de tramvai
        self.urm.actualizeaza(boxes, np.asarray(confs, float), cats, polys, t)
        for p in self.urm.piste:
            if p.t_ultim == t:
                self._analizeaza(p, t)
                if p.stare == "miscare" and p.a_miscat and not p.parcat and 0 < dt < 2:
                    self.harta.adauga(p.box, dt, *marime)
        self.harta.salveaza()
        return self.instantaneu()

    def _analizeaza(self, p, t):
        S = SETARI
        W = S["fereastra_viteza"]
        ist = [e for e in p.istoric if t - e[0] <= W]
        if len(ist) >= 3 and ist[-1][0] - ist[0][0] >= 0.5 * W:
            n = max(1, len(ist) // 3)
            A = np.median(np.array([e[1:5] for e in ist[:n]]), 0)  # x1,y1,x2,y2 la inceput
            B = np.median(np.array([e[1:5] for e in ist[-n:]]), 0)  # ... la sfarsit
            mid = len(ist) // 2
            Mm = np.median(np.array([e[1:5] for e in ist[max(0, mid - n // 2):mid + n // 2 + 1]]), 0)
            dtw = max(np.mean([e[0] for e in ist[-n:]]) - np.mean([e[0] for e in ist[:n]]), 1e-3)
            ca = np.array([(A[0] + A[2]) / 2, (A[1] + A[3]) / 2])
            cb = np.array([(B[0] + B[2]) / 2, (B[1] + B[3]) / 2])
            # deplasarea centrului SI a marginii de jos (vehiculele care se departeaza de
            # camera se misca putin pe imagine, dar marginea de jos tot urca)
            dep = max(np.linalg.norm(cb - ca), abs(B[3] - A[3]))
            v = dep / dtw                                   # pixeli / secunda
            ref = min(B[2] - B[0], B[3] - B[1])            # marimea vehiculului
            prag_m = max(S["miscare_px"], S["miscare_rel"] * ref)
            prag_o = max(S["oprire_px"], S["oprire_rel"] * ref)
            if p.stare == "miscare":
                if v < prag_o:
                    p.stare = "oprit"
                    p.t_oprit = t
            else:
                # miscare reala = deplasare constanta in aceeasi directie (nu "tremurat" de chenar)
                cm = np.array([(Mm[0] + Mm[2]) / 2, (Mm[1] + Mm[3]) / 2])
                d1, d2 = cm - ca, cb - cm
                consecvent = (np.dot(d1, d2) > 0) or ((Mm[3] - A[3]) * (B[3] - Mm[3]) > 0)
                if v > prag_m and consecvent:
                    p.stare = "miscare"
                elif p.stare == "nou":
                    p.stare = "oprit"
                    p.t_oprit = p.t_start
            if p.stare == "miscare":
                d = cb - ca
                nd = np.linalg.norm(d)
                if nd > 0:
                    d = d / nd
                    p.directie = d if p.directie is None else (0.6 * p.directie + 0.4 * d)
                    p.directie = p.directie / (np.linalg.norm(p.directie) + 1e-9)
        h = p.inaltime()
        lung = max(p.box[2] - p.box[0], p.box[3] - p.box[1])
        p.parcurs = max(p.parcurs, np.linalg.norm(p.centru() - p.poz_start) / lung)
        if p.parcurs >= 1.0:
            p.a_miscat = True

        if p.parcat:
            if p.stare == "miscare" and np.linalg.norm(p.centru() - p.poz_parcare) / h > 0.7:
                p.parcat = False      # pleaca din parcare
                p.t_oprit = t
                p.poz_start, p.parcurs = p.centru(), 0.0
            return
        if p.stare != "oprit":
            return
        cat = p.categorie()
        if cat == "tramvai":
            return  # tramvaiele nu sunt niciodata "parcate"
        oprit_de = t - p.t_oprit
        z, W_, H_ = self.zone, *self.marime
        baza = ((p.box[0] + p.box[2]) / 2, p.box[3])
        if z.contine("parcare", baza):
            parcheaza = oprit_de >= S["parcat_zona_parcare"]
        elif cat != "autobuz" and oprit_de >= S["parcat_dupa"]:
            parcheaza = True                       # nemiscat foarte mult timp
        elif z.contine("drum", baza):
            parcheaza = False                      # zona de drum desenata de utilizator
        elif self.harta.invatata():
            if self.harta.e_drum(p.box, W_, H_):
                parcheaza = False                  # oprit pe drum -> conteaza (semafor, coada)
            else:
                parcheaza = (not p.a_miscat and oprit_de >= S["parcat_afara_nemiscat"]) or \
                            oprit_de >= S["parcat_afara_oprit"]
        else:
            parcheaza = (not p.a_miscat and oprit_de >= S["parcat_harta_neinvatata"])
        if parcheaza:
            p.parcat = True
            p.poz_parcare = p.centru()

    def instantaneu(self):
        t = self.t
        elemente = []
        stat = Counter()
        dir_cnt = Counter()
        for p in self.urm.piste:
            if p.hits < 2 or t - p.t_ultim > 0.6:
                continue
            cat = p.categorie()
            b = tuple(int(v) for v in p.box)
            if p.parcat:
                stare = "parcat"
                stat["parcate"] += 1
            else:
                stare = p.stare
                if stare != "nou":
                    stat[(cat, stare)] += 1
            dir_idx = None
            if stare == "miscare" and p.directie is not None:
                ang = math.degrees(math.atan2(-p.directie[1], p.directie[0])) % 360
                dir_idx = int(((ang + 22.5) % 360) // 45)
                dir_cnt[dir_idx] += 1
            sec = int(t - p.t_oprit) if stare == "oprit" else 0
            poly = None if p.poligon is None else np.asarray(p.poligon).astype(int).tolist()
            elemente.append(dict(id=p.id, box=b, poly=poly, cat=cat, stare=stare, sec=sec,
                                 dir=None if p.directie is None else tuple(p.directie),
                                 dir_idx=dir_idx))
        return dict(elemente=elemente, stat=stat, directii=dir_cnt, t=t,
                    harta_invatata=self.harta.invatata(), harta_min=self.harta.total / 60)


def eticheta(e, unicode=True):
    if e["stare"] == "parcat":
        return "P"
    s = NUME_CAT[e["cat"]]
    if e["stare"] == "oprit":
        s += f" OPRIT {e['sec']}s"
    elif e["stare"] == "miscare" and e["dir_idx"] is not None:
        s += " " + (SAGETI[e["dir_idx"]] if unicode else DIRECTII[e["dir_idx"]])
    return s


def culoare(e):
    if e["stare"] in ("parcat", "nou"):
        return CULORI[e["stare"]]
    return CULORI[(e["cat"], e["stare"])]


def text_statistici(inst, unicode=True):
    s = inst["stat"]
    r = []
    for cat, plural in (("masina", "Masini"), ("autobuz", "Autobuze"), ("tramvai", "Tramvaie")):
        r.append(f"{plural}: {s[(cat, 'miscare')]} in miscare, {s[(cat, 'oprit')]} oprite")
    r.append(f"Parcate (ignorate): {s['parcate']}")
    d = inst["directii"]
    if d:
        sag = SAGETI if unicode else DIRECTII
        r.append("Directii: " + "  ".join(f"{sag[i]} {d[i]}" for i in sorted(d)))
    if not inst.get("harta_invatata", True):
        r.append(f"Invat drumul... ({inst.get('harta_min', 0) * 60 / 180 * 100:.0f}%)")
    return r


# ---------------------------------------------------------------------------
# Desenare pe imagine (mod fereastra / video)
# ---------------------------------------------------------------------------
def deseneaza(img, inst, zone=None, harta=None, arata_parcate=True, arata_zone=False, fps=None):
    H, W = img.shape[:2]
    fs = max(0.4, W / 2600)
    th = 1 if W < 1600 else 2
    if arata_zone:
        if harta is not None:
            cv2.polylines(img, harta.contururi(W, H), True, hex_bgr(CULOARE_HARTA), 1, cv2.LINE_AA)
        if zone is not None:
            zone.pregateste(W, H)
            for tip, polis in zone.px.items():
                for poly in polis:
                    cv2.polylines(img, [poly.astype(np.int32)], True, hex_bgr(CULORI_ZONE[tip]), 1, cv2.LINE_AA)
    for e in inst["elemente"]:
        if e["stare"] == "parcat" and not arata_parcate:
            continue
        x1, y1, x2, y2 = e["box"]
        col = hex_bgr(culoare(e))
        gros = 1 if e["stare"] == "parcat" else th + 1
        if e["poly"] is not None:
            cv2.polylines(img, [np.array(e["poly"], np.int32)], True, col, gros, cv2.LINE_AA)
            x1, y1 = np.min(e["poly"], 0)
        else:
            cv2.rectangle(img, (x1, y1), (x2, y2), col, gros, cv2.LINE_AA)
        txt = eticheta(e, unicode=False)
        (tw, tht), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, fs, th)
        fundal = hex_bgr(CULORI["oprit_tag"]) if e["stare"] == "oprit" else col
        cv2.rectangle(img, (x1, y1 - tht - 6), (x1 + tw + 4, y1), fundal, -1)
        cv2.putText(img, txt, (x1 + 2, y1 - 4), cv2.FONT_HERSHEY_SIMPLEX, fs, (0, 0, 0), th, cv2.LINE_AA)
        if e["stare"] == "miscare" and e["dir"] is not None:
            bx1, by1, bx2, by2 = e["box"]
            cx, cy = (bx1 + bx2) // 2, (by1 + by2) // 2
            L = 0.8 * max(bx2 - bx1, by2 - by1)
            cv2.arrowedLine(img, (cx, cy), (int(cx + e["dir"][0] * L), int(cy + e["dir"][1] * L)),
                            col, th + 1, cv2.LINE_AA, tipLength=0.3)
    linii = text_statistici(inst, unicode=False)
    if fps is not None:
        linii.insert(0, f"FPS analiza: {fps:.1f}")
    lh = int(26 * fs / 0.5)
    cv2.rectangle(img, (0, 0), (int(560 * fs / 0.5), lh * len(linii) + 10), (0, 0, 0), -1)
    for i, l in enumerate(linii):
        cv2.putText(img, l, (8, lh * (i + 1)), cv2.FONT_HERSHEY_SIMPLEX, fs, (255, 255, 255), th, cv2.LINE_AA)
    return img


# ---------------------------------------------------------------------------
# Detector (ultralytics): YOLOE cu cuvinte (are "tram") sau YOLO clasic (COCO)
# ---------------------------------------------------------------------------
class DetectorYOLO:
    def __init__(self, model=MODEL_IMPLICIT, imgsz=960, device=None, openvino=None):
        from ultralytics import YOLO
        try:
            import torch
            cuda = torch.cuda.is_available() and device != "cpu"
        except Exception:
            cuda = False
        if openvino is None:                      # automat: OpenVINO cand nu e placa NVIDIA
            openvino = not cuda
        stem = os.path.splitext(os.path.basename(model))[0]
        e_yoloe = "yoloe" in stem.lower()
        dir_ov = os.path.join(AICI, stem + "_openvino_dinamic")
        m = None
        if openvino and os.path.isdir(dir_ov):
            m = self._incarca_openvino(dir_ov, model)
        if m is None:
            if e_yoloe:
                from ultralytics import YOLOE
                m = YOLOE(model)
                cache = os.path.join(AICI, f"prompturi_{stem}.npz")
                incarcat = False
                if os.path.exists(cache):
                    try:
                        m.load_prompt_embeddings(cache)
                        incarcat = list(m.names.values() if isinstance(m.names, dict) else m.names) == PROMPTURI
                    except Exception:
                        incarcat = False
                if not incarcat:
                    print("Prima pornire: pregatesc cuvintele (descarca ~250 MB o singura data)...")
                    m.set_classes(PROMPTURI)
                    try:
                        m.save_prompt_embeddings(cache)
                    except Exception:
                        pass
            else:
                m = YOLO(model)
            if openvino:
                try:
                    print("Optimizez modelul pentru procesor cu OpenVINO (doar prima data, 1-3 min)...")
                    iesire = m.export(format="openvino", dynamic=True, half=False, imgsz=imgsz)
                    if os.path.abspath(str(iesire)) != dir_ov:
                        if os.path.isdir(dir_ov):
                            import shutil
                            shutil.rmtree(dir_ov)
                        os.replace(str(iesire), dir_ov)
                    m_ov = self._incarca_openvino(dir_ov, model)
                    if m_ov is not None:
                        m = m_ov
                except Exception as ex:
                    print(f"OpenVINO nu a mers ({ex!r}); continui fara.")
        self.m = m
        nume = m.names if isinstance(m.names, dict) else dict(enumerate(m.names))
        self.id_cat = {int(i): NUME_LA_CAT[n] for i, n in nume.items() if n in NUME_LA_CAT}
        self.clase = sorted(self.id_cat)
        if e_yoloe:
            SETARI["conf_min"], SETARI["conf_nou"] = 0.10, 0.25
        self.imgsz = imgsz
        self.device = device
        self.half = bool(cuda) and not self.ov
        if self.ov:
            print("Rulez pe procesor, accelerat cu OpenVINO.")
        elif cuda:
            import torch
            print(f"Rulez pe placa video: {torch.cuda.get_device_name(0)} (FP16)")
        else:
            print("Rulez pe procesor (CPU). Daca e lent: --model yoloe-26n-seg.pt --imgsz 640")

    ov = False

    def _incarca_openvino(self, dir_ov, model):
        from ultralytics import YOLO
        try:
            m = YOLO(dir_ov, task="segment" if "seg" in model else "detect")
            m.predict(np.zeros((480, 640, 3), np.uint8), imgsz=640, verbose=False)  # test
            self.ov = True
            return m
        except Exception as ex:
            print(f"Nu pot folosi modelul OpenVINO ({ex!r}); continui fara.")
            return None

    def __call__(self, frame, imgsz=None):
        kw = dict(imgsz=imgsz or self.imgsz, conf=SETARI["conf_min"], classes=self.clase,
                  agnostic_nms=True, verbose=False)
        if self.device is not None and not self.ov:
            kw["device"] = self.device
        if self.half:
            kw["half"] = True
        r = self.m.predict(frame, **kw)[0]
        b = r.boxes
        cls = b.cls.cpu().numpy().astype(int)
        cats = [self.id_cat.get(int(c), "masina") for c in cls]
        polys = None
        if r.masks is not None:
            polys = [simplifica_contur(p) for p in r.masks.xy]
        return b.xyxy.cpu().numpy(), b.conf.cpu().numpy(), cats, polys


class DetectorDecupat:
    """Trimite la model doar zona cu drum (invatata). Aceeasi finete, mult mai putini pixeli."""

    def __init__(self, detector, harta, zone, imgsz):
        self.det, self.harta, self.zone, self.imgsz = detector, harta, zone, imgsz
        self.roi_curent = None

    def __call__(self, frame):
        H, W = frame.shape[:2]
        r = self.harta.roi(W, H, self.zone)
        self.roi_curent = r
        if r is None:
            return self.det(frame)
        x1, y1, x2, y2 = r
        decupaj = frame[y1:y2, x1:x2]
        # aceeasi scara ca pe imaginea intreaga -> rezolutie mai mica, la multiplu de 64
        scara = self.imgsz / max(W, H)
        imgsz = int(max(320, min(self.imgsz, round(max(x2 - x1, y2 - y1) * scara / 64) * 64)))
        b, c, k, pl = self.det(decupaj, imgsz=imgsz)
        if len(b):
            b = b + np.array([x1, y1, x1, y1], np.float32)
        if pl is not None:
            pl = [None if p is None else p + np.array([x1, y1]) for p in pl]
        return b, c, k, pl


def creeaza_detector(a):
    try:
        return DetectorYOLO(a.model, a.imgsz, a.device, a.openvino)
    except Exception as ex:
        if a.model == MODEL_REZERVA:
            raise
        print(f"\nNu am putut porni modelul {a.model}: {ex!r}")
        print(f"Folosesc modelul clasic {MODEL_REZERVA} (fara clasa 'tramvai').\n")
        return DetectorYOLO(MODEL_REZERVA, a.imgsz, a.device, a.openvino)


# ---------------------------------------------------------------------------
# Surse de imagine
# ---------------------------------------------------------------------------
def regiune_ecran(cfg):
    import mss
    with mss.mss() as sct:
        mon_idx = int(cfg.get("monitor", 1))
        mon_idx = mon_idx if mon_idx < len(sct.monitors) else 1
        mon = sct.monitors[mon_idx]
    r = cfg.get("regiune")
    if r:
        return dict(left=int(r[0]), top=int(r[1]), width=int(r[2]), height=int(r[3]))
    return dict(left=mon["left"], top=mon["top"], width=mon["width"], height=mon["height"])


class SursaEcran:
    def __init__(self, regiune, fps_max=15):
        self.reg = regiune
        self.perioada = 1.0 / fps_max
        self.sct = None
        self._ultim = 0

    def citeste(self):
        import mss
        if self.sct is None:
            self.sct = mss.mss()  # creat in firul care il foloseste
        astept = self.perioada - (time.time() - self._ultim)
        if astept > 0:
            time.sleep(astept)
        self._ultim = time.time()
        img = np.asarray(self.sct.grab(self.reg))
        return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR), time.time()


class SursaVideo:
    def __init__(self, cale, fps_analiza=10, start=0.0, durata=None):
        self.cap = cv2.VideoCapture(cale)
        if not self.cap.isOpened():
            raise SystemExit(f"Nu pot deschide {cale}")
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 30
        self.pas = max(1, round(self.fps / fps_analiza))
        self.i = int(start * self.fps)
        self.stop = None if durata is None else self.i + int(durata * self.fps)
        if self.i:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.i)

    def citeste(self):
        if self.stop is not None and self.i >= self.stop:
            return None, None
        ok, f = self.cap.read()
        if not ok:
            return None, None
        t = self.i / self.fps
        for _ in range(self.pas - 1):
            self.cap.grab()
        self.i += self.pas
        return f, t


# ---------------------------------------------------------------------------
# Configurare interactiva (zona de ecran + zone optionale)
# ---------------------------------------------------------------------------
def incarca_config(cale):
    if os.path.exists(cale):
        with open(cale, encoding="utf-8") as f:
            return json.load(f)
    return {"monitor": 1, "regiune": None, "zone": {}}


def salveaza_config(cale, cfg):
    with open(cale, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=1, ensure_ascii=False)
    print(f"Configuratie salvata: {cale}")


def meta_harta(cfg):
    return {"monitor": int(cfg.get("monitor", 1)), "regiune": cfg.get("regiune")}


def _incape(img, maxw=1500, maxh=850):
    h, w = img.shape[:2]
    s = min(maxw / w, maxh / h, 1.0)
    return cv2.resize(img, (int(w * s), int(h * s))) if s < 1 else img.copy(), s


def editor_zone(img, zone_existente):
    vis0, s = _incape(img)
    H, W = vis0.shape[:2]
    zone = {k: [list(p) for p in zone_existente.get(k, [])] for k in ("drum", "tramvai", "parcare")}
    curent, mod = [], "parcare"
    taste = {ord("d"): "drum", ord("t"): "tramvai", ord("p"): "parcare"}
    fer = "Zone optionale - vezi instructiunile din imagine"

    def inchide():
        nonlocal curent
        if len(curent) >= 3:
            zone[mod].append(curent)
        curent = []

    def mouse(ev, x, y, *_):
        if ev == cv2.EVENT_LBUTTONDOWN:
            curent.append([round(x / W, 4), round(y / H, 4)])
        elif ev == cv2.EVENT_RBUTTONDOWN:
            inchide()

    cv2.namedWindow(fer)
    cv2.setMouseCallback(fer, mouse)
    instr = [
        "OPTIONAL - drumul se invata singur. Apasa s daca nu vrei sa desenezi nimic.",
        "Click stanga = punct | Click dreapta / Enter = inchide poligonul",
        "p = PARCARE (masinile oprite aici = parcate)   d = DRUM (aici oprit = in trafic)",
        "t = TRAMVAI (doar pt. modelul clasic)   z = anuleaza  c = sterge  s = SALVEAZA  Esc = renunta",
    ]
    while True:
        vis = vis0.copy()
        strat = vis.copy()
        for tip, polis in zone.items():
            for p in polis:
                pts = (np.array(p) * [W, H]).astype(np.int32)
                cv2.fillPoly(strat, [pts], hex_bgr(CULORI_ZONE[tip]))
                cv2.polylines(vis, [pts], True, hex_bgr(CULORI_ZONE[tip]), 2)
        vis = cv2.addWeighted(strat, 0.25, vis, 0.75, 0)
        if curent:
            pts = (np.array(curent) * [W, H]).astype(np.int32)
            cv2.polylines(vis, [pts], False, hex_bgr(CULORI_ZONE[mod]), 2)
            for q in pts:
                cv2.circle(vis, tuple(int(v) for v in q), 4, (255, 255, 255), -1)
        cv2.rectangle(vis, (0, 0), (W, 22 * (len(instr) + 1) + 6), (0, 0, 0), -1)
        for i, l in enumerate(instr):
            cv2.putText(vis, l, (8, 20 + 22 * i), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(vis, f"MOD CURENT: {mod.upper()}", (8, 20 + 22 * len(instr)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, hex_bgr(CULORI_ZONE[mod]), 2, cv2.LINE_AA)
        cv2.imshow(fer, vis)
        k = cv2.waitKey(30) & 0xFF
        if k in taste:
            inchide()
            mod = taste[k]
        elif k in (13, 10, 32):
            inchide()
        elif k == ord("z"):
            if curent:
                curent.pop()
            elif zone[mod]:
                zone[mod].pop()
        elif k == ord("c"):
            zone[mod], curent = [], []
        elif k == ord("s"):
            inchide()
            cv2.destroyWindow(fer)
            return zone
        elif k == 27:
            cv2.destroyWindow(fer)
            return None
        if cv2.getWindowProperty(fer, cv2.WND_PROP_VISIBLE) < 1:
            return None


def configurare(cale_cfg, video=None):
    cfg = incarca_config(cale_cfg)
    if video:
        cap = cv2.VideoCapture(video)
        ok, img = cap.read()
        if not ok:
            raise SystemExit("Nu pot citi videoclipul")
    else:
        import mss
        with mss.mss() as sct:
            mon_idx = int(cfg.get("monitor", 1))
            mon = sct.monitors[mon_idx if mon_idx < len(sct.monitors) else 1]
            print("Peste 2 secunde fac o captura de ecran. Lasa vizibil stream-ul camerei...")
            time.sleep(2)
            ecran = cv2.cvtColor(np.asarray(sct.grab(mon)), cv2.COLOR_BGRA2BGR)
        vis, s = _incape(ecran)
        print("Trage un dreptunghi peste imaginea camerei, apoi Enter. (Enter fara selectie = tot ecranul)")
        x, y, w, h = cv2.selectROI("Selecteaza imaginea camerei + Enter", vis, showCrosshair=False)
        cv2.destroyAllWindows()
        if w > 10 and h > 10:
            X, Y, Wd, Hd = int(x / s), int(y / s), int(w / s), int(h / s)
            cfg["regiune"] = [mon["left"] + X, mon["top"] + Y, Wd, Hd]
            img = ecran[Y:Y + Hd, X:X + Wd]
        else:
            cfg["regiune"] = None
            img = ecran
    zone = editor_zone(img, cfg.get("zone", {}))
    if zone is None:
        print("Renuntat - nimic salvat.")
        return
    cfg["zone"] = zone
    salveaza_config(cale_cfg, cfg)


# ---------------------------------------------------------------------------
# Overlay transparent peste ecran (Windows)
# ---------------------------------------------------------------------------
class Motor(threading.Thread):
    """Fir de lucru: captura -> detectie -> urmarire -> analiza."""

    def __init__(self, sursa, detector, analizor):
        super().__init__(daemon=True)
        self.sursa, self.det, self.an = sursa, detector, analizor
        self.lacat = threading.Lock()
        self.ultim = None
        self.versiune = 0
        self.fps = 0.0
        self.oprit = False
        self.eroare = None

    def run(self):
        try:
            while not self.oprit:
                t0 = time.time()
                frame, t = self.sursa.citeste()
                if frame is None:
                    break
                b, c, k, pl = self.det(frame)
                inst = self.an.actualizeaza(b, c, k, pl, t, (frame.shape[1], frame.shape[0]))
                dt = time.time() - t0
                self.fps = 0.8 * self.fps + 0.2 * (1 / max(dt, 1e-3)) if self.fps else 1 / max(dt, 1e-3)
                with self.lacat:
                    self.ultim = inst
                    self.versiune += 1
        except Exception as ex:  # afisam eroarea in panou
            self.eroare = repr(ex)
            raise


def _win_exclude_din_captura(hwnd, click_prin=False):
    import ctypes
    u32 = ctypes.windll.user32
    if click_prin:
        GWL_EXSTYLE = -20
        stil = u32.GetWindowLongW(hwnd, GWL_EXSTYLE)
        stil |= 0x80000 | 0x20 | 0x80 | 0x08000000  # LAYERED|TRANSPARENT|TOOLWINDOW|NOACTIVATE
        u32.SetWindowLongW(hwnd, GWL_EXSTYLE, stil)
    WDA_EXCLUDEFROMCAPTURE = 0x11
    return bool(u32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE))


class Overlay:
    CHEIE = "#010203"  # culoarea care devine transparenta

    def __init__(self, motor, regiune, zone, harta):
        import tkinter as tk
        import tkinter.font as tkfont
        import ctypes
        self.tk = tk
        self.motor, self.zone, self.harta = motor, zone, harta
        x, y, w, h = regiune["left"], regiune["top"], regiune["width"], regiune["height"]
        self.w, self.h = w, h
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.root.configure(bg=self.CHEIE)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", self.CHEIE)
        self.cv = tk.Canvas(self.root, width=w, height=h, bg=self.CHEIE, highlightthickness=0)
        self.cv.pack()
        self.font = tkfont.Font(family="Segoe UI", size=9, weight="bold")
        self.root.update_idletasks()
        hwnd = ctypes.windll.user32.GetAncestor(self.root.winfo_id(), 2)
        self.exclus = _win_exclude_din_captura(hwnd, click_prin=True)
        if not self.exclus:
            print("ATENTIE: Windows nu permite excluderea overlay-ului din captura "
                  "(e nevoie de Windows 10 2004+). Contururile pot fi 'vazute' de detector. "
                  "Foloseste --mod fereastra daca apar probleme.")

        # panou de control
        self.panou = tk.Toplevel(self.root)
        self.panou.title("Detector intersectie")
        self.panou.attributes("-topmost", True)
        self.panou.geometry(f"+{x + 20}+{y + 60}")
        self.panou.configure(bg="#1b1b1b")
        self.lbl = tk.Label(self.panou, text="Pornesc modelul...", justify="left", anchor="w",
                            font=("Segoe UI", 10), fg="white", bg="#1b1b1b", padx=10, pady=8)
        self.lbl.pack(fill="x")
        self.v_parcate = tk.BooleanVar(value=True)
        self.v_zone = tk.BooleanVar(value=False)
        self.v_ascuns = tk.BooleanVar(value=False)
        for txt, var in (("Arata masinile parcate (gri)", self.v_parcate),
                         ("Arata drumul invatat", self.v_zone),
                         ("Ascunde contururile", self.v_ascuns)):
            tk.Checkbutton(self.panou, text=txt, variable=var, fg="white", bg="#1b1b1b",
                           selectcolor="#333", activebackground="#1b1b1b", activeforeground="white",
                           command=self._forteaza).pack(anchor="w", padx=8)
        tk.Button(self.panou, text="Opreste", command=self.inchide, bg="#a01818", fg="white",
                  relief="flat", padx=12).pack(pady=8)
        self.panou.protocol("WM_DELETE_WINDOW", self.inchide)
        self.panou.update_idletasks()
        _win_exclude_din_captura(ctypes.windll.user32.GetAncestor(self.panou.winfo_id(), 2))
        self.vers_desenata = -1
        self._ultim_lift = time.time()
        self.root.after(50, self._bucla)

    def _forteaza(self):
        self.vers_desenata = -1

    def inchide(self):
        self.motor.oprit = True
        self.harta.salveaza(fortat=True)
        self.root.destroy()

    def _bucla(self):
        with self.motor.lacat:
            inst, vers = self.motor.ultim, self.motor.versiune
        if inst is not None and vers != self.vers_desenata:
            self.vers_desenata = vers
            self._deseneaza(inst)
            linii = [f"FPS analiza: {self.motor.fps:.1f}"] + text_statistici(inst)
            self.lbl.config(text="\n".join(linii))
        if self.motor.eroare:
            self.lbl.config(text="EROARE:\n" + self.motor.eroare, fg="#ff6060")
        if time.time() - self._ultim_lift > 3:  # ramanem deasupra browserului
            self._ultim_lift = time.time()
            self.root.attributes("-topmost", True)
            self.root.lift()
            self.panou.lift()
        self.root.after(30, self._bucla)

    def _deseneaza(self, inst):
        cv = self.cv
        cv.delete("all")
        if self.v_ascuns.get():
            return
        if self.v_zone.get():
            for c in self.harta.contururi(self.w, self.h):
                if len(c) >= 3:
                    cv.create_polygon(*c.flatten().tolist(), outline=CULOARE_HARTA, fill="", width=2)
            self.zone.pregateste(self.w, self.h)
            for tip, polis in self.zone.px.items():
                for p in polis:
                    cv.create_polygon(*p.flatten().tolist(), outline=CULORI_ZONE[tip], fill="",
                                      dash=(6, 4), width=2)
        for e in inst["elemente"]:
            if e["stare"] == "parcat" and not self.v_parcate.get():
                continue
            x1, y1, x2, y2 = e["box"]
            col = culoare(e)
            parcat = e["stare"] == "parcat"
            if e["poly"] is not None:
                pts = [v for q in e["poly"] for v in q]
                cv.create_polygon(*pts, outline=col, fill="", width=1 if parcat else 3,
                                  dash=(3, 3) if parcat else None)
                lx, ly = min(q[0] for q in e["poly"]), min(q[1] for q in e["poly"])
            else:
                cv.create_rectangle(x1, y1, x2, y2, outline=col, width=1 if parcat else 3,
                                    dash=(3, 3) if parcat else None)
                lx, ly = x1, y1
            if parcat:
                continue
            txt = eticheta(e)
            tw = self.font.measure(txt) + 6
            fundal = CULORI["oprit_tag"] if e["stare"] == "oprit" else col
            cv.create_rectangle(lx, ly - 17, lx + tw, ly, fill=fundal, outline=fundal)
            cv.create_text(lx + 3, ly - 9, text=txt, anchor="w", font=self.font,
                           fill="white" if e["stare"] == "oprit" else "black")
            if e["stare"] == "miscare" and e["dir"] is not None:
                cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
                L = 0.8 * max(x2 - x1, y2 - y1)
                cv.create_line(cx, cy, cx + e["dir"][0] * L, cy + e["dir"][1] * L, fill=col,
                               width=3, arrow=self.tk.LAST, arrowshape=(12, 14, 5))

    def ruleaza(self):
        self.root.mainloop()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def dpi_aware():
    if sys.platform == "win32":
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass


def ruleaza_bucla_simpla(sursa, detector, analizor, zone, afiseaza=True, salveaza=None, titlu="Detector"):
    """Mod fereastra / fisier video: o singura bucla, imaginea adnotata in fereastra OpenCV."""
    scriitor = None
    arata_parcate, arata_zone = True, False
    fps = 0.0
    try:
        while True:
            t0 = time.time()
            frame, t = sursa.citeste()
            if frame is None:
                break
            b, c, k, pl = detector(frame)
            inst = analizor.actualizeaza(b, c, k, pl, t, (frame.shape[1], frame.shape[0]))
            dt = time.time() - t0
            fps = 0.8 * fps + 0.2 / max(dt, 1e-3) if fps else 1 / max(dt, 1e-3)
            out = deseneaza(frame, inst, zone, analizor.harta, arata_parcate, arata_zone, fps)
            if salveaza:
                if scriitor is None:
                    fps_out = getattr(sursa, "fps", 30) / getattr(sursa, "pas", 1)
                    scriitor = cv2.VideoWriter(salveaza, cv2.VideoWriter_fourcc(*"mp4v"), fps_out,
                                               (out.shape[1], out.shape[0]))
                scriitor.write(out)
            if afiseaza:
                vis, _ = _incape(out, 1600, 900)
                cv2.imshow(titlu + "  (q = iesire, p = parcate, z = drum invatat)", vis)
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break
                if key == ord("p"):
                    arata_parcate = not arata_parcate
                if key == ord("z"):
                    arata_zone = not arata_zone
    finally:
        analizor.harta.salveaza(fortat=True)
        if scriitor:
            scriitor.release()
            print(f"Salvat: {salveaza}")
        if afiseaza:
            cv2.destroyAllWindows()


def main():
    ap = argparse.ArgumentParser(description="Detector live de vehicule in intersectie")
    ap.add_argument("--configurare", action="store_true", help="alege zona de ecran (+ zone optionale)")
    ap.add_argument("--config", default=CONFIG_IMPLICIT)
    ap.add_argument("--mod", choices=["overlay", "fereastra"], default=None,
                    help="overlay = contururi direct pe ecran (implicit pe Windows); fereastra = fereastra separata")
    ap.add_argument("--video", help="analizeaza un fisier video in loc de ecran")
    ap.add_argument("--salveaza", help="salveaza videoclipul adnotat (cu --video)")
    ap.add_argument("--model", default=MODEL_IMPLICIT,
                    help="yoloe-26s-seg.pt (implicit, recunoaste tramvaie) / yoloe-26n-seg.pt (rapid) / "
                         "yoloe-26m-seg.pt (precis) / yolo11s-seg.pt (clasic)")
    ap.add_argument("--imgsz", type=int, default=960, help="rezolutia de analiza (mai mare = vede masini mai mici)")
    ap.add_argument("--device", default=None, help="cpu, 0 (placa NVIDIA)... implicit automat")
    ap.add_argument("--openvino", dest="openvino", action="store_true", default=None,
                    help="forteaza OpenVINO (implicit: automat cand nu ai placa NVIDIA)")
    ap.add_argument("--fara-openvino", dest="openvino", action="store_false")
    ap.add_argument("--fara-decupare", action="store_true",
                    help="analizeaza toata imaginea, nu doar zona cu drum")
    ap.add_argument("--fps-max", type=float, default=15)
    ap.add_argument("--monitor", type=int, default=None, help="numarul monitorului (1 = principal)")
    ap.add_argument("--parcat-dupa", type=float, default=SETARI["parcat_dupa"],
                    help="secunde nemiscat dupa care o masina e considerata parcata (implicit 120)")
    ap.add_argument("--reseteaza-harta", action="store_true", help="uita drumul invatat si invata din nou")
    a = ap.parse_args()
    SETARI["parcat_dupa"] = a.parcat_dupa

    dpi_aware()
    if a.configurare:
        if a.monitor:
            cfg = incarca_config(a.config)
            cfg["monitor"] = a.monitor
            salveaza_config(a.config, cfg)
        configurare(a.config, a.video)
        return

    cfg = incarca_config(a.config)
    if a.monitor:
        cfg["monitor"] = a.monitor
    zone = Zone(cfg.get("zone"))
    if a.video:
        cale_harta = os.path.splitext(a.video)[0] + "_harta.npz"
        meta = {"video": os.path.basename(a.video)}
    else:
        cale_harta, meta = HARTA_IMPLICIT, meta_harta(cfg)
    if a.reseteaza_harta and os.path.exists(cale_harta):
        os.remove(cale_harta)
        print("Harta drumului stearsa - o invat din nou.")
    harta = HartaTrafic(cale_harta, meta)

    print(f"Incarc modelul {a.model} ...")
    detector = creeaza_detector(a)
    if not a.fara_decupare:
        detector = DetectorDecupat(detector, harta, zone, a.imgsz)
    analizor = Analizor(zone, harta)

    if a.video:
        ruleaza_bucla_simpla(SursaVideo(a.video), detector, analizor, zone, True, a.salveaza, a.video)
        return

    reg = regiune_ecran(cfg)
    print(f"Captez ecranul: {reg}")
    mod = a.mod or ("overlay" if sys.platform == "win32" else "fereastra")
    sursa = SursaEcran(reg, a.fps_max)
    if mod == "fereastra":
        print("Muta fereastra de rezultat pe alt monitor sau langa stream (sa nu acopere camera).")
        ruleaza_bucla_simpla(sursa, detector, analizor, zone, True, None, "Detector live")
        return
    motor = Motor(sursa, detector, analizor)
    ov = Overlay(motor, reg, zone, harta)
    motor.start()
    print("Ruleaza. Inchide din panoul 'Detector intersectie' (butonul Opreste).")
    try:
        ov.ruleaza()
    finally:
        motor.oprit = True
        harta.salveaza(fortat=True)


if __name__ == "__main__":
    main()
